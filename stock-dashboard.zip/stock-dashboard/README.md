# stock dashboard

been messing around with stocks lately and wanted to actually understand the charts people always post. built this so i could visualize price history, volume, RSI etc without having to pay for some app.

data is fake/simulated for now (working on hooking up a real API when i have time) but the charts and layout all work.

---

## what it does

- switch between AAPL, GOOGL, MSFT, NVDA, TSLA
- 1M / 3M / 6M / 1Y time ranges
- price chart, volume bars, RSI indicator
- shows key stats (market cap, P/E, 52 week highs/lows etc)
- export to CSV if you want to mess with the data in excel or whatever

---

## running it

no setup needed, just open `index.html` in your browser. that's it.

if you want a local server for some reason:

```bash
python3 -m http.server 8080
```

then go to `localhost:8080`

---

## files

```
stock-dashboard/
├── index.html
├── src/
│   ├── styles.css    
│   ├── data.js       # stock data + RSI math
│   ├── charts.js     # chart.js stuff
│   └── app.js        # buttons, state, etc
```

---

## todo / ideas

- [ ] hook up a real stock API (looking at Alpha Vantage, it's free)
- [ ] add more tickers
- [ ] maybe candlestick chart instead of line?
- [ ] portfolio tracker would be cool

---

## notes

built with vanilla JS + [Chart.js](https://www.chartjs.org/). no frameworks, no node_modules, nothing to install.

RSI formula taken from investopedia and translated into JS — seemed to work out

feel free to use/modify whatever
