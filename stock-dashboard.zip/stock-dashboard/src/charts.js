// ── Chart instances ────────────────────────────────────────────────────────
let priceChart, volumeChart, rsiChart;

// ── Color helpers ──────────────────────────────────────────────────────────
function isUp(ticker) { return STOCK_DATA[ticker].change >= 0; }

function trendColors(ticker) {
  const up = isUp(ticker);
  return {
    line: up ? '#1D9E75' : '#E24B4A',
    fill: up ? 'rgba(29,158,117,0.08)' : 'rgba(226,75,74,0.08)',
  };
}

// ── Shared axis config ─────────────────────────────────────────────────────
const axisBase = {
  ticks : { font: { family: 'Courier New, monospace', size: 11 }, color: '#55555f' },
  grid  : { color: 'rgba(255,255,255,0.04)' },
  border: { display: false },
};

// ── Price chart ────────────────────────────────────────────────────────────
function drawPriceChart(ticker, range) {
  const { prices, labels } = getChartData(ticker, range);
  const { line, fill }     = trendColors(ticker);

  if (priceChart) priceChart.destroy();
  priceChart = new Chart(document.getElementById('priceChart'), {
    type: 'line',
    data: {
      labels,
      datasets: [{
        data            : prices.map(p => +p.toFixed(2)),
        borderColor     : line,
        backgroundColor : fill,
        fill            : true,
        borderWidth     : 1.5,
        pointRadius     : 0,
        tension         : 0.3,
      }],
    },
    options: {
      responsive            : true,
      maintainAspectRatio   : false,
      plugins: {
        legend : { display: false },
        tooltip: {
          mode     : 'index',
          intersect: false,
          callbacks: { label: ctx => ' $' + ctx.parsed.y.toFixed(2) },
        },
      },
      scales: {
        x: { ...axisBase, ticks: { ...axisBase.ticks, maxTicksLimit: 8, autoSkip: true }, grid: { display: false } },
        y: { ...axisBase, ticks: { ...axisBase.ticks, callback: v => '$' + v.toFixed(0) } },
      },
    },
  });
}

// ── Volume chart ───────────────────────────────────────────────────────────
function drawVolumeChart(ticker, range) {
  const { vols, labels } = getChartData(ticker, range);

  if (volumeChart) volumeChart.destroy();
  volumeChart = new Chart(document.getElementById('volumeChart'), {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data           : vols.map(v => +(v / 1e6).toFixed(1)),
        backgroundColor: 'rgba(127,119,221,0.25)',
        borderWidth    : 0,
      }],
    },
    options: {
      responsive          : true,
      maintainAspectRatio : false,
      plugins: {
        legend : { display: false },
        tooltip: { callbacks: { label: ctx => ' ' + ctx.parsed.y.toFixed(1) + 'M' } },
      },
      scales: {
        x: { display: false },
        y: { ...axisBase, ticks: { ...axisBase.ticks, callback: v => v + 'M' } },
      },
    },
  });
}

// ── RSI chart ──────────────────────────────────────────────────────────────
function drawRSIChart(ticker, range) {
  const { rsi, labels } = getChartData(ticker, range);

  if (rsiChart) rsiChart.destroy();
  rsiChart = new Chart(document.getElementById('rsiChart'), {
    type: 'line',
    data: {
      labels,
      datasets: [
        { data: rsi,                                        borderColor: '#7f77dd', backgroundColor: 'transparent', borderWidth: 1.5, pointRadius: 0, tension: 0.3 },
        { data: new Array(labels.length).fill(70),          borderColor: 'rgba(226,75,74,0.5)',  borderWidth: 1, borderDash: [4,3], pointRadius: 0, fill: false },
        { data: new Array(labels.length).fill(30),          borderColor: 'rgba(29,158,117,0.5)', borderWidth: 1, borderDash: [4,3], pointRadius: 0, fill: false },
      ],
    },
    options: {
      responsive          : true,
      maintainAspectRatio : false,
      plugins: { legend: { display: false } },
      scales: {
        x: { display: false },
        y: { ...axisBase, min: 0, max: 100, ticks: { ...axisBase.ticks, stepSize: 25 } },
      },
    },
  });
}

// ── Render all three ───────────────────────────────────────────────────────
function drawAllCharts(ticker, range) {
  drawPriceChart(ticker, range);
  drawVolumeChart(ticker, range);
  drawRSIChart(ticker, range);
}
