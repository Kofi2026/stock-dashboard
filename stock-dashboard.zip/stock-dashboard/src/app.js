// tickers + ranges — add more here if needed
const TICKERS = ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'TSLA'];
const RANGES  = ['1M', '3M', '6M', '1Y'];

let currentTicker = 'AAPL';
let currentRange  = '1M';

// builds the metric cards at the top
function renderMetrics(ticker) {
  const d    = STOCK_DATA[ticker];
  const up   = d.change >= 0;
  const sign = up ? '+' : '';
  const cls  = up ? 'up' : 'down';

  document.getElementById('metricsSection').innerHTML = `
    <div class="metric-card">
      <div class="metric-label">Price</div>
      <div class="metric-value">$${d.price.toFixed(2)}</div>
      <div class="metric-change ${cls}">${sign}${d.change.toFixed(2)} (${sign}${d.changePct.toFixed(2)}%)</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">Open</div>
      <div class="metric-value">$${d.open.toFixed(2)}</div>
      <div class="metric-change muted">today</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">High / Low</div>
      <div class="metric-value" style="font-size:16px;">$${d.high.toFixed(2)}<br><span style="color:var(--text-2);">$${d.low.toFixed(2)}</span></div>
    </div>
    <div class="metric-card">
      <div class="metric-label">Volume</div>
      <div class="metric-value">${d.vol}</div>
      <div class="metric-change muted">today</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">Mkt Cap</div>
      <div class="metric-value">${d.mktCap}</div>
      <div class="metric-change muted">USD</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">P/E Ratio</div>
      <div class="metric-value">${d.pe}</div>
      <div class="metric-change muted">trailing</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">52W High</div>
      <div class="metric-value">$${d.week52High.toFixed(2)}</div>
      <div class="metric-change down">${(d.price - d.week52High).toFixed(2)} from high</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">52W Low</div>
      <div class="metric-value">$${d.week52Low.toFixed(2)}</div>
      <div class="metric-change up">+${((d.price / d.week52Low - 1) * 100).toFixed(1)}% from low</div>
    </div>
  `;
}

// generic helper to build a row of toggle buttons
function buildButtonGroup(containerId, items, activeItem, className, onClick) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  items.forEach(item => {
    const btn = document.createElement('button');
    btn.className = className + (item === activeItem ? ' active' : '');
    btn.textContent = item;
    btn.addEventListener('click', () => onClick(item, btn));
    container.appendChild(btn);
  });
}

function setActiveBtn(container, btn, className) {
  container.querySelectorAll('.' + className).forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function setTicker(ticker, btn) {
  currentTicker = ticker;
  setActiveBtn(document.getElementById('tickerSelector'), btn, 'ticker-btn');
  renderMetrics(ticker);
  drawAllCharts(ticker, currentRange);
}

function setRange(range, btn) {
  currentRange = range;
  setActiveBtn(document.getElementById('rangeSelector'), btn, 'range-btn');
  drawAllCharts(currentTicker, range);
}

function bindActions() {
  // TODO: hook this up to a real API at some point
  document.getElementById('btnTrend').addEventListener('click', () => {
    alert('trend analysis coming soon — need to wire up an API for this');
  });

  document.getElementById('btnPeers').addEventListener('click', () => {
    alert('peer comparison coming soon');
  });

  document.getElementById('btnExport').addEventListener('click', () => {
    exportCSV(currentTicker, currentRange);
  });
}

function init() {
  buildButtonGroup('tickerSelector', TICKERS, currentTicker, 'ticker-btn', setTicker);
  buildButtonGroup('rangeSelector',  RANGES,  currentRange,  'range-btn',  setRange);
  renderMetrics(currentTicker);
  drawAllCharts(currentTicker, currentRange);
  bindActions();
}

document.addEventListener('DOMContentLoaded', init);
