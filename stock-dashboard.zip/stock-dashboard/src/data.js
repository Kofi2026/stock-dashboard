// hardcoded for now — want to replace this with a real API call eventually
// grabbed these numbers manually so they'll go stale, not a big deal for a demo
const STOCK_DATA = {
  AAPL:  { price: 189.84, change: 2.31,  changePct: 1.23,  open: 187.20, high: 191.05, low: 186.80, vol: '58.2M', mktCap: '2.94T', pe: 31.2, week52High: 199.62, week52Low: 124.17 },
  GOOGL: { price: 141.70, change: -0.85, changePct: -0.60, open: 142.30, high: 143.10, low: 140.50, vol: '22.4M', mktCap: '1.79T', pe: 25.8, week52High: 153.78, week52Low: 102.21 },
  MSFT:  { price: 378.91, change: 4.12,  changePct: 1.10,  open: 374.50, high: 380.22, low: 373.80, vol: '21.1M', mktCap: '2.81T', pe: 36.4, week52High: 384.30, week52Low: 275.37 },
  NVDA:  { price: 495.22, change: 18.33, changePct: 3.84,  open: 476.50, high: 498.11, low: 473.20, vol: '45.8M', mktCap: '1.22T', pe: 65.1, week52High: 502.66, week52Low: 138.84 },
  TSLA:  { price: 248.50, change: -6.40, changePct: -2.51, open: 255.00, high: 256.80, low: 246.30, vol: '112.3M', mktCap: '790B',  pe: 72.3, week52High: 299.29, week52Low: 138.80 },
};

// how jumpy each stock is — TSLA and NVDA move a lot more than MSFT
const VOLATILITY = { AAPL: 0.012, GOOGL: 0.013, MSFT: 0.011, NVDA: 0.025, TSLA: 0.030 };

// seeded random so the charts don't change every time you refresh
// found this trick on stackoverflow
function seededRandom(seed) {
  let x = Math.sin(seed) * 10000;
  return () => { x = Math.sin(x) * 10000; return x - Math.floor(x); };
}

function generatePrices(base, n, volatility, rng) {
  const prices = [base * 0.85];
  for (let i = 1; i < n; i++) {
    const drift = (rng() - 0.48) * volatility;
    prices.push(Math.max(base * 0.5, prices[i - 1] * (1 + drift)));
  }
  // make sure the last point is the actual current price
  prices[prices.length - 1] = base;
  return prices;
}

// RSI formula from investopedia, translated into JS
// period 14 is the standard apparently
function computeRSI(prices, period = 14) {
  const rsi = new Array(period).fill(null);
  for (let i = period; i < prices.length; i++) {
    let gains = 0, losses = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const delta = prices[j] - prices[j - 1];
      if (delta > 0) gains += delta; else losses -= delta;
    }
    const rs = losses === 0 ? 100 : gains / losses;
    rsi.push(Math.round(100 - 100 / (1 + rs)));
  }
  return rsi;
}

function generateLabels(n, rangeKey) {
  const labels = [];
  const now = new Date(2026, 2, 13);
  const days = { '1M': 22, '3M': 66, '6M': 130, '1Y': 252 }[rangeKey] || 22;
  const step = Math.max(1, Math.floor(days / n));
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i * step);
    labels.push(d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
  }
  return labels;
}

function getChartData(ticker, range) {
  const d = STOCK_DATA[ticker];
  const n = { '1M': 22, '3M': 60, '6M': 120, '1Y': 252 }[range] || 22;
  const vol = VOLATILITY[ticker] || 0.015;
  const seed = ticker.charCodeAt(0) * 7 + range.length * 13;
  const rng = seededRandom(seed * 137.5);

  const prices = generatePrices(d.price, n, vol, rng);
  const vols   = Array.from({ length: n }, () => Math.round((rng() * 60 + 20) * 1e6));
  const rsi    = computeRSI(prices);
  const labels = generateLabels(n, range);
  return { prices, vols, rsi, labels };
}

// downloads the data as a csv — useful for throwing into excel or python
function exportCSV(ticker, range) {
  const { prices, vols, rsi, labels } = getChartData(ticker, range);
  const rows = [['Date', 'Price', 'Volume', 'RSI']];
  labels.forEach((label, i) => {
    rows.push([label, prices[i].toFixed(2), vols[i], rsi[i] ?? '']);
  });
  const csv = rows.map(r => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), { href: url, download: `${ticker}_${range}.csv` });
  a.click();
  URL.revokeObjectURL(url);
}
